import sys; sys.path.insert(0, '/testbed/tests')
import os, django
os.environ['DJANGO_SETTINGS_MODULE']='test_sqlite'
django.setup()
from django.test.utils import setup_test_environment, setup_databases, teardown_databases
setup_test_environment()
from django.test.runner import DiscoverRunner
runner = DiscoverRunner(verbosity=0, interactive=False)
old_config = setup_databases(verbosity=0, interactive=False, )

from django.conf import settings
from django.apps.registry import apps
from django.contrib.contenttypes.models import ContentType
from django.core.management import call_command
from django.test import override_settings

class TestRouter:
    def db_for_write(self, model, **hints):
        return 'default'

with override_settings(DATABASE_ROUTERS=[TestRouter()]):
    ContentType.objects.using('other').create(app_label='contenttypes_tests', model='foo')
    other = ContentType.objects.using('other').filter(app_label='contenttypes_tests')
    call_command('migrate', 'contenttypes_tests', database='other', interactive=False, verbosity=0)
    print('foo exists #1:', other.filter(model='foo').exists())
    print('renamedfoo exists:', other.filter(model='renamedfoo').exists())
    print('foo exists #2:', other.filter(model='foo').exists())
    print('all other cts:', list(ContentType.objects.using('other').filter(app_label='contenttypes_tests').values_list('model', flat=True)))
    print('all default cts:', list(ContentType.objects.using('default').filter(app_label='contenttypes_tests').values_list('model', flat=True)))

teardown_databases(old_config, verbosity=0)
