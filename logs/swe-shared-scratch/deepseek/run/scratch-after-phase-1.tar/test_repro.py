import astropy.units as u

def test_constructor_none():
    class PoC(object):
        @u.quantity_input
        def __init__(self, voltage: u.V) -> None:
            pass
    p = PoC(1.*u.V)
    assert p is not None

def test_return_annotation():
    @u.quantity_input
    def f(x: u.m) -> u.cm:
        return x
    assert f(1*u.m).unit == u.cm

def test_return_none_annotation():
    @u.quantity_input
    def g(x: u.m) -> None:
        return None
    assert g(1*u.m) is None
